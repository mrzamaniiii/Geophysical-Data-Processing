
Ts = 0.005;          % Sampling interval
N = 200;             % Number of samples
Fs = 1/Ts;           % Sampling frequency
Nyquist = Fs / 2;    % Nyquist frequency
max_amp = 0.5;       % Maximum amplitude

t = (0:N-1) * Ts;

% Generate Noise Sequence
noise_raw = rand(1, N); 
noise = (2 * max_amp * noise_raw) - max_amp;

% 2. Calculate and Plot Noise Spectra
Noise_Spectrum = fft(noise);

% Calculate One-Sided Amplitude Spectrum
P2_noise = abs(Noise_Spectrum / N);
P1_noise = P2_noise(1:N/2+1);
P1_noise(2:end-1) = 2 * P1_noise(2:end-1);

% Calculate One-Sided Phase Spectrum
P_noise = angle(Noise_Spectrum);
P_noise_one_sided = P_noise(1:N/2+1);

% Generate One-Sided Frequency Vector
f = linspace(0, Nyquist, N/2 + 1);

figure('Name', 'Noise Spectrum and Autocorrelation');

% Plot Noise Amplitude Spectrum
subplot(4, 2, [1 3]); 
stem(f, P1_noise, 'b', 'LineWidth', 1);
title('A) Noise Amplitude Spectrum');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
axis([0 Nyquist 0 max(P1_noise)*1.1]);
grid on;

% Plot Noise Phase Spectrum
subplot(4, 2, [5 7]); 
stem(f, P_noise_one_sided, 'b', 'LineWidth', 1);
title('B) Noise Phase Spectrum');
xlabel('Frequency (Hz)');
ylabel('Phase (rad)');
grid on;

% 3. Generate Autocorrelation Spectrum
Autocorr_Spectrum = Noise_Spectrum .* conj(Noise_Spectrum);

% 4. Plot Autocorrelation Spectra and Comparison

% Calculate One-Sided Amplitude Spectrum
P2_autocorr = abs(Autocorr_Spectrum / N);
P1_autocorr = P2_autocorr(1:N/2+1);
P1_autocorr(2:end-1) = 2 * P1_autocorr(2:end-1);

% Calculate One-Sided Phase Spectrum
P_autocorr = angle(Autocorr_Spectrum);
P_autocorr_one_sided = P_autocorr(1:N/2+1);

subplot(4, 2, [2 4]); 
stem(f, P1_autocorr, 'r', 'LineWidth', 1);
title('C) Autocorr. Amplitude Spectrum (Power Spectral Density)');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
axis([0 Nyquist 0 max(P1_autocorr)*1.1]);
grid on;

subplot(4, 2, [6 8]); 
stem(f, P_autocorr_one_sided, 'r', 'LineWidth', 1);
title('D) Autocorr. Phase Spectrum');
xlabel('Frequency (Hz)');
ylabel('Phase (rad)');
grid on;

% 5. Inverse Transform and Comparison
autocorr_freq_domain = ifft(Autocorr_Spectrum);

% Autocorrelation in the time domain
[autocorr_time_domain_full, lags] = xcorr(noise, 'none');
tau = lags * Ts;

tau_iff = linspace(-N/2, N/2 - 1, N) * Ts; 
autocorr_freq_domain_shifted = fftshift(autocorr_freq_domain);
figure('Name', 'Autocorrelation Comparison');

subplot(2, 1, 1);
plot(tau, autocorr_time_domain_full, 'b-', 'LineWidth', 2);
title('E) Autocorrelation (Time Domain - XCORR Baseline)');
xlabel('Lag Time (\tau) (s)');
ylabel('Amplitude');
grid on;

% Plot IFFT result (N points) - FIX
subplot(2, 1, 2);
plot(tau_iff, real(autocorr_freq_domain_shifted), 'r--', 'LineWidth', 1.5); 
title('F) Autocorrelation (Frequency Domain - IFFT)');
xlabel('Lag Time (\tau) (s)');
ylabel('Amplitude');
grid on;

% 6. Clear Workspace
clear;
disp('Workspace cleared.');