Ts = 0.005;          % Sampling interval
Fs = 1/Ts;           % Sampling frequency
N = 200;             % Number of samples
V = 300;             % Surface wave velocity
dx = 6;              % Geophone interval
num_geophones = 13;   % Number of geophones

% Time delay
dt_per_dx = dx / V;

% 2. Generate Impulse Response
impulse_response = zeros(1, N);

for k = 0:num_geophones-1
    time_delay = k * dt_per_dx;
    
    % Find the closest sample index
    sample_index = round(time_delay / Ts) + 1;
    
    if sample_index <= N
        impulse_response(sample_index) = 1;
    end
end

% 3. Calculate and Plot the Transfer Function

Transfer_Function = fft(impulse_response);

% Calculate the One-Sided Amplitude Spectrum (Magnitude Response)
P2 = abs(Transfer_Function / N); 
P1 = P2(1:N/2+1);
P1(2:end-1) = 2 * P1(2:end-1);   

% Generate Frequency Vector
Nyquist = Fs / 2;
f = linspace(0, Nyquist, N/2 + 1);

figure('Name', 'Geophone Array Transfer Function');
plot(f, P1, 'b-', 'LineWidth', 2);
title('Amplitude Transfer Function of 13-Geophone Array');
xlabel('Frequency (Hz)');
ylabel('Normalized Amplitude |H(f)|');
grid on;


% 4. Evaluate the Filtered Band
f_null_primary = 1 / dt_per_dx;

hold on;
plot([4 46], [0.15 0.15], 'k--', 'LineWidth', 1.5);
text(25, 0.2, 'Expected Filtered Band: 4-46 Hz', 'HorizontalAlignment', 'center', 'FontSize', 10);
hold off;

fprintf('Time delay between adjacent geophones (dt): %.3f s\n', dt_per_dx);
fprintf('Theoretical primary frequency notch (f_null): %.2f Hz\n', f_null_primary);

% 5. Clear Workspace
clear;
disp('Workspace cleared.');

