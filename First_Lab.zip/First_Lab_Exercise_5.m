
Ts = 0.005;          % Sampling time interval
Fs = 1/Ts;           % Sampling frequency
N = 200;             % Total number of samples
T_pulse = 0.050;     % Pulse duration

N_pulse = T_pulse / Ts; 

t = (0:N-1) * Ts;

% 2. Generate the Pulse (Raised Cosine using 'hann')
pulse_shape = hann(N_pulse)'; 

pulse_padded = [pulse_shape, zeros(1, N - N_pulse)];

% 3. Generate the Reflectivity Function (4 Delta Functions)
reflectivity = zeros(1, N);

% Define locations
reflectivity(30) = 0.8; 
reflectivity(65) = -0.5;
reflectivity(100) = 1.0;
reflectivity(150) = -0.3;

% 4. Convolve the Pulse with the Reflectivity Function
convolution_result_long = conv(pulse_shape, reflectivity);

% Truncate the result
convolution_result = convolution_result_long(1:N);

% 5. Plot the Results for Comparison
figure('Name', 'Convolution of Pulse and Reflectivity');

% Subplot 1: The Pulse
subplot(3, 1, 1);
plot(t, pulse_padded, 'g-', 'LineWidth', 2);
title('A) Input Pulse (50ms Raised Cosine)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Subplot 2: The Reflectivity Function
subplot(3, 1, 2);
stem(t, reflectivity, 'k', 'LineWidth', 2);
title('B) Reflectivity Function (4 Delta Functions)');
xlabel('Time (s)');
ylabel('Amplitude');
ylim([-1.2 1.2]);
grid on;

% Subplot 3: The Convolution Result
subplot(3, 1, 3);
plot(t, convolution_result, 'r-', 'LineWidth', 2);
title('C) Convolution Output');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;
