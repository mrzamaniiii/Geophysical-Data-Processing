
Ts = 0.005;          % Sampling interval
N = 200;             % Number of samples
Fs = 1/Ts;           % Sampling frequency
t = (0:N-1) * Ts;    % Time vector

% 2. Generate Sinusoidal Signal
f_signal = 10;
A_signal = 1.0;

signal = A_signal * sin(2*pi*f_signal*t);

% 3. Generate Noise Sequence
max_noise_amp = 2.0;

noise_raw = rand(1, N); 

% Scale and shift the noise
noise = (2 * max_noise_amp * noise_raw) - max_noise_amp;

% 4. Sum Signal and Noise
signal_with_noise = signal + noise;

% 5. Apply Autocorrelation
[autocorr_result, lags] = xcorr(signal_with_noise, 'coeff');

tau = lags * Ts;


figure('Name', 'Signal Detection using Autocorrelation');

subplot(2, 1, 1);
plot(t, signal_with_noise, 'k-', 'LineWidth', 1, 'DisplayName', 'Signal + Noise');
hold on;
plot(t, signal, 'b--', 'LineWidth', 2, 'DisplayName', 'Original Signal');
hold off;
title('A) Sinusoidal Signal Corrupted by High Amplitude Noise');
xlabel('Time (s)');
ylabel('Amplitude');
legend('show');
grid on;

subplot(2, 1, 2);
plot(tau, autocorr_result, 'r-', 'LineWidth', 2);
title('B) Autocorrelation: Detection of Periodic Component');
xlabel('Lag Time (\tau) (s)');
ylabel('Normalized Autocorrelation');
grid on;
