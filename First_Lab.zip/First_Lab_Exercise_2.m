Ts = 0.005;          
Fs = 1/Ts;           
N = 200;             
t_end = (N-1) * Ts;  

t = 0:Ts:t_end;

f1 = 5;      
p1 = 0;      
A1 = 1.0;    

f2 = 20;     
p2 = pi/2;   
A2 = 0.5;   

f3 = 45;     
p3 = pi;     
A3 = 0.2;    

y = A1 * sin(2*pi*f1*t + p1) + ...
    A2 * sin(2*pi*f2*t + p2) + ...
    A3 * sin(2*pi*f3*t + p3);

figure('Name', 'Periodic Function and Spectrum Analysis');

subplot(2, 1, 1);
plot(t, y, 'b-');
title('Time Domain Signal (Sum of Three Sine Waves)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

Y = fft(y);

P2 = abs(Y / N);

P1 = P2(1:N/2+1);
P1(2:end-1) = 2 * P1(2:end-1);

f = Fs*(0:(N/2))/N;

subplot(2, 1, 2);
plot(f, P1, 'r-');
title('Amplitude Spectrum');
xlabel('Frequency (Hz)');
ylabel('|P1(f)|');
grid on;

Nyquist = Fs / 2;
axis([0 Nyquist 0 max(P1)*1.1]);