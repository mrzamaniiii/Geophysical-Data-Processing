N = 32;

pulse_2D = zeros(N, N);
pulse_2D(N/2 + 1, N/2 + 1) = 1; 

% 2. Plot the 2D Function
figure('Name', '2D Pulse and Spectrum');

% Create coordinate vectors (optional, but good practice for surf)
[X, Y] = meshgrid(1:N, 1:N);

subplot(2, 2, 1);
surf(X, Y, pulse_2D);
title('A) 2D Ideal Pulse (Space Domain)');
xlabel('X'); ylabel('Y'); zlabel('Amplitude');
shading flat;
axis tight;

% 3. Calculate the 2D Fourier Transform (FFT2) ---
Pulse_Spectrum = fft2(pulse_2D);
Amplitude_Spectrum_Shifted = fftshift(abs(Pulse_Spectrum));

% 4. Plot the Amplitude Spectrum using 'surf' ---
subplot(2, 2, 2);
surf(X, Y, Amplitude_Spectrum_Shifted);
title('B) Amplitude Spectrum of 2D Pulse');
xlabel('Fx'); ylabel('Fy'); zlabel('|F|');
shading flat;
axis tight;

Fx_cos = 3;
Fy_cos = 0;

[x_norm, y_norm] = meshgrid(linspace(0, 2*pi, N), linspace(0, 2*pi, N));
cosine_2D = cos(Fx_cos * x_norm + Fy_cos * y_norm);

% 6. Plot the 2D Cosine Function
subplot(2, 2, 3);
surf(X, Y, cosine_2D);
title('C) 2D Cosine Wave (Space Domain)');
xlabel('X'); ylabel('Y'); zlabel('Amplitude');
shading flat;
axis tight;

Cosine_Spectrum = fft2(cosine_2D);
Amplitude_Cosine_Shifted = fftshift(abs(Cosine_Spectrum));

subplot(2, 2, 4);
surf(X, Y, Amplitude_Cosine_Shifted);
title('D) Amplitude Spectrum of 2D Cosine Wave');
xlabel('Fx'); ylabel('Fy'); zlabel('|F|');
shading flat;
axis tight;