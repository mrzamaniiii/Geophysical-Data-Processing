Ts = 0.005;          % Sampling interval
Fs = 1/Ts;           % Sampling frequency
N = 200;             % Number of samples
t = (0:N-1) * Ts;    % Time vector

reflectivity = zeros(1, N);
reflectivity(20) = 0.9;    
reflectivity(45) = -0.4; 
reflectivity(80) = 1.0; 
reflectivity(120) = -0.6;
reflectivity(170) = 0.8; 

% 2. Generate Zero-Phase Band-Pass Filter Transfer Function
f_center = 25;       
N_hann = 31;        
Nyquist = Fs / 2;

f_norm = 40 / Nyquist;
Hd = fir1(N_hann - 1, f_norm, 'low');

f_shift = f_center / Nyquist;
n = 0:N_hann-1;
cosine_mod = cos(2*pi*f_shift * n);

% Modulate the low-pass filter to get a zero-phase Band-Pass Filter (BPF) kernel
BPF_kernel = Hd .* cosine_mod; 

% Pad the kernel to length N (200) for FFT calculation
BPF_kernel_padded = [BPF_kernel, zeros(1, N - N_hann)];

% Calculate the FFT
Transfer_Function = fft(BPF_kernel_padded);

TF_plot_shifted = fftshift(abs(Transfer_Function));

% Frequency vector for plotting
f_full = linspace(-Nyquist, Nyquist - Fs/N, N);

figure('Name', 'Band-Pass Filter Design and Application');

subplot(3, 1, 1);
plot(f_full, TF_plot_shifted, 'b-', 'LineWidth', 2);
title(['A) Zero-Phase Band-Pass Filter Transfer Function (Centered at ', num2str(f_center), ' Hz)']);
xlabel('Frequency (Hz)');
ylabel('Amplitude |H(f)|');
grid on;
axis([-Nyquist Nyquist 0 1.1*max(TF_plot_shifted)]);

% 3. Apply the Filter

% Calculate spectrum of reflectivity
Reflectivity_Spectrum = fft(reflectivity);

% Apply filter
Filtered_Spectrum = Reflectivity_Spectrum .* Transfer_Function;

% Apply inverse FFT to get the filtered signal
filtered_signal = ifft(Filtered_Spectrum);

% 4. Extract Envelope using Analytic Signal

Analytic_Spectrum = zeros(1, N);

Analytic_Spectrum(1:N/2+1) = 2 * Filtered_Spectrum(1:N/2+1);
Analytic_Spectrum(1) = Filtered_Spectrum(1);             % DC
Analytic_Spectrum(N/2 + 1) = Filtered_Spectrum(N/2 + 1); % Nyquist

analytic_signal = ifft(Analytic_Spectrum);

% The envelope is the magnitude (amplitude) of the analytic signal
envelope_freq = abs(analytic_signal);

analytic_signal_hilbert = hilbert(real(filtered_signal)); 
envelope_hilbert = abs(analytic_signal_hilbert);

figure('Name', 'Filtered Signal and Envelope Extraction');

subplot(2, 1, 1);
plot(t, real(filtered_signal), 'b-', 'LineWidth', 1, 'DisplayName', 'Filtered Signal');
hold on;
plot(t, envelope_freq, 'r--', 'LineWidth', 2, 'DisplayName', 'Envelope (Freq Domain)');
title('B) Filtered Signal and Envelope (Frequency Domain Method)');
xlabel('Time (s)');
ylabel('Amplitude');
legend('show');
grid on;

subplot(2, 1, 2);
plot(t, real(filtered_signal), 'b-', 'LineWidth', 1, 'DisplayName', 'Filtered Signal');
hold on;
plot(t, envelope_hilbert, 'g--', 'LineWidth', 2, 'DisplayName', 'Envelope (Hilbert Command)');
title('C) Filtered Signal and Envelope (Hilbert Command Method)');
xlabel('Time (s)');
ylabel('Amplitude');
legend('show');
grid on;

clear;
disp('Workspace cleared.');