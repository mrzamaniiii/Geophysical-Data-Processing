Ts = 0.005;          % Sampling interval
N = 200;             % Number of samples
Fs = 1/Ts;           % Sampling frequency
max_amp = 0.5;       % Maximum amplitude for noise

t = (0:N-1) * Ts;

% 2. Generate Noise Sequence
noise_raw = rand(1, N); 

% Scale and shift the noise:
noise = (2 * max_amp * noise_raw) - max_amp;


% 3. Calculate Autocorrelation (using xcorr)
[autocorr_result, lags] = xcorr(noise, 'coeff');

% Lags vector provides the time shift
tau = lags * Ts;

% 4. Plot the Noise Signal and Autocorrelation
figure('Name', 'Noise Signal and Autocorrelation Analysis');

subplot(2, 1, 1);
plot(t, noise, 'b.', 'MarkerSize', 8);
title('A) Generated Noise Sequence (Amplitude: -0.5 to 0.5)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

subplot(2, 1, 2);
plot(tau, autocorr_result, 'r-', 'LineWidth', 1.5);
hold on;
stem(0, autocorr_result(lags == 0), 'ko', 'filled', 'MarkerSize', 8);
hold off;
title('B) Autocorrelation of the Noise Signal');
xlabel('Lag Time (\tau) (s)');
ylabel('Normalized Autocorrelation');
grid on;