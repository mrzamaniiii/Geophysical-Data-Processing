Ts = 0.005;          % Sampling interval
N = 200;             % Number of samples
max_noise_amp = 0.5; 
t = (0:N-1) * Ts;

% 2. Generate Noise Sequence
noise_raw = rand(1, N); 
noise = (2 * max_noise_amp * noise_raw) - max_noise_amp;

% 3. Generate Reflectivity Function
reflectivity = zeros(1, N);
reflectivity(30) = 0.8; 
reflectivity(65) = -0.5;
reflectivity(100) = 1.0;
reflectivity(150) = -0.3;

% 4. Convolve Noise
convolved_noise_long = conv(noise, reflectivity);
convolved_noise = convolved_noise_long(1:N);

% 5. Apply Matched Filter
[filtered_result, lags] = xcorr(convolved_noise, noise, 'coeff');

% Convert lag indices to time
tau = lags * Ts;

% 6. Plotting the Results
figure('Name', 'Noise Convolution and Matched Filtering');

% Plot 1: Convolved Noise Signal
subplot(2, 1, 1);
plot(t, convolved_noise, 'k-', 'LineWidth', 1);
title('A) Noise Sequence Convolved with Reflectivity');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Plot 2: Matched Filter Output
subplot(2, 1, 2);
plot(tau, filtered_result, 'r-', 'LineWidth', 2);
title('B) Matched Filter Output (Cross-Correlation)');
xlabel('Lag Time (\tau) (s)');
ylabel('Normalized Correlation');
grid on;

% 7. Clear Workspace
clear;
disp('Workspace cleared.');