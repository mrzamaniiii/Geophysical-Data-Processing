Ts = 0.005;          % Sampling time interval
Fs = 1/Ts;           % Sampling frequency
N = 200;             % Total number of samples
T_pulse = 0.050;     % Pulse duration

% Number of samples
N_pulse = T_pulse / Ts; 

t = 0:Ts:(N-1)*Ts;

y = zeros(1, N);

pulse = ones(1, N_pulse);

start_index = 51;
end_index = start_index + N_pulse - 1;

y(start_index:end_index) = pulse;

figure('Name', 'Rectangular Pulse Analysis');

subplot(2, 1, 1);
plot(t, y, 'b-', 'LineWidth', 2);
title('Time Domain: Rectangular Pulse (50ms)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;
ylim([-0.2 1.2]); 

% Compute the FFT
Y = fft(y);

% Calculate the two-sided amplitude spectrum
P2 = abs(Y / N);

% Calculate the one-sided amplitude spectrum
P1 = P2(1:N/2+1);
P1(2:end-1) = 2 * P1(2:end-1); % Scaling for one-sided spectrum

Nyquist = Fs / 2; % 100 Hz
f = linspace(0, Nyquist, N/2 + 1);

subplot(2, 1, 2);
stem(f, P1, 'r-', 'LineWidth', 1.5);
title('Amplitude Spectrum');
xlabel('Frequency (Hz)');
ylabel('|P1(f)|');

axis([0 Nyquist 0 max(P1)*1.1]);

grid on;
