Ts = 0.005;          % Sampling interval
T = 1;               % Signal duration
Fs = 1/Ts;           % Sampling frequency
N = round(T/Ts);     % Number of samples

t = (0:N-1) * Ts;    % Time vector

f_start = 10;        % Starting frequency
f_end = 60;          % Ending frequency

% 2. Generate Linear Sweep Signal (Chirp)
sweep_signal = chirp(t, f_start, T, f_end);

% 3. Plot the Sweep Signal
figure('Name', 'Linear Sweep Signal and Analysis');

subplot(3, 1, 1);
plot(t, sweep_signal, 'b-', 'LineWidth', 1.5);
title(['A) Linear Sweep Signal (Chirp) from ', num2str(f_start), ' to ', num2str(f_end), ' Hz']);
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% 4. Apply Fourier Transform
% Calculate FFT
Y = fft(sweep_signal);

% Calculate One-Sided Amplitude Spectrum
P2 = abs(Y / N);
P1 = P2(1:N/2+1);
P1(2:end-1) = 2 * P1(2:end-1);

% Generate Frequency Vector
Nyquist = Fs / 2;
f = linspace(0, Nyquist, N/2 + 1);

subplot(3, 1, 2);
plot(f, P1, 'r-', 'LineWidth', 1.5);
title('B) Amplitude Spectrum of Sweep Signal');
xlabel('Frequency (Hz)');
ylabel('|P1(f)|');

axis([0 65 0 max(P1)*1.1]);
grid on;

% 5. Calculate and Plot Autocorrelation ---
[autocorr_result, lags] = xcorr(sweep_signal, 'coeff');

tau = lags * Ts;

subplot(3, 1, 3);
plot(tau, autocorr_result, 'k-', 'LineWidth', 1.5);
title('C) Autocorrelation of Sweep Signal');
xlabel('Lag Time (\tau) (s)');
ylabel('Normalized Autocorrelation');
grid on;