Ts = 0.001;          % Sampling interval
Fs = 1/Ts;           % Sampling frequency
T_duration = 1;      % Signal duration
N = T_duration / Ts; % Number of samples

f_signal = 180;      % Signal frequency

% Time vector for original signal
t = (0:N-1) * Ts;

% Original sinusoidal signal
signal_original = sin(2*pi*f_signal*t);

% 2. Downsample the Signal
downsample_factor = 5;
Fs_new = Fs / downsample_factor;
N_new = N / downsample_factor;

signal_downsampled = downsample(signal_original, downsample_factor);

t_new = (0:N_new-1) * (Ts * downsample_factor);

% 3. Plot Time Domain Comparison
figure('Name', 'Time Domain Comparison: Original vs. Downsampled');

subplot(2, 1, 1);
plot(t, signal_original, 'b-', 'LineWidth', 1);
title(['A) Original Signal (f = 180 Hz, Fs = ', num2str(Fs), ' Hz)']);
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

subplot(2, 1, 2);
stem(t_new, signal_downsampled, 'r.', 'MarkerSize', 8);
hold on;
plot(t_new, signal_downsampled, 'r--', 'LineWidth', 0.5);
hold off;
title(['B) Downsampled Signal (Fs = ', num2str(Fs_new), ' Hz): Apparent Alias at 20 Hz']);
xlabel('Time (s)');
ylabel('Amplitude');
grid on;


% 4. Calculate and Plot Amplitude Spectra Comparison ---

Y_orig = fft(signal_original);
P1_orig = abs(Y_orig(1:N/2+1)) / N;
P1_orig(2:end-1) = 2 * P1_orig(2:end-1);
f_orig = linspace(0, Fs/2, N/2 + 1);

Y_down = fft(signal_downsampled);
P1_down = abs(Y_down(1:N_new/2+1)) / N_new;
P1_down(2:end-1) = 2 * P1_down(2:end-1);
f_down = linspace(0, Fs_new/2, N_new/2 + 1); % Nyquist is 100 Hz

figure('Name', 'Amplitude Spectra Comparison');

plot(f_orig, P1_orig, 'b-', 'LineWidth', 1.5, 'DisplayName', ['Original (Peak at ', num2str(f_signal), ' Hz)']);
hold on;
stem(f_down, P1_down, 'r', 'LineWidth', 2, 'DisplayName', ['Downsampled (Peak at 20 Hz)']);
hold off;

title('Amplitude Spectra Comparison (0 - 200 Hz)');
xlabel('Frequency (Hz)');
ylabel('Normalized Amplitude');
legend('show');

axis([0 200 0 max(P1_orig)*1.2]); 
grid on;