clear;
clc;
close all;

fs = 200;             
T = 1;                 
dt = 1/fs;             
t = 0:dt:T-dt;         
N = length(t);

reflectivity = zeros(N, 1);
num_pulses = 5;

rand_indices = randperm(N, num_pulses);
rand_amplitudes = 2 * rand(num_pulses, 1) - 1;
reflectivity(rand_indices) = rand_amplitudes;

figure(1);
stem(t, reflectivity, 'filled');
title('1. Reflectivity Function (Ideal Pulses)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;
ylim([-1.1 1.1]);

win_length = 31;
fc = 25;                
h = hann(win_length);
t_win = (-(win_length-1)/2:(win_length-1)/2) * dt;
filter_kernel = h' .* cos(2 * pi * fc * t_win);

N_fft = 1024; 
H = fft(filter_kernel, N_fft);
H_mag = abs(fftshift(H)); 
f_axis = (-N_fft/2:N_fft/2-1) * fs / N_fft;

figure(2);
plot(f_axis, H_mag);
title('Transfer Function of the filter');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;
xlim([-fs/2 fs/2]);


% Apply the Filter
filtered_signal = conv(reflectivity, filter_kernel, 'same');

figure(3);
plot(t, filtered_signal);
title('Filtered Signal');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;



% FFT of the filtered signal
X_fft = fft(filtered_signal);
N_filt = length(filtered_signal);

analytic_spectrum = X_fft;
analytic_spectrum(2 : floor(N_filt/2)) = 2 * analytic_spectrum(2 : floor(N_filt/2));
analytic_spectrum(floor(N_filt/2)+2 : end) = 0;

analytic_signal_freq = ifft(analytic_spectrum);
envelope_freq = abs(analytic_signal_freq);

figure(4);
plot(t, filtered_signal, 'b', 'DisplayName', 'Filtered Signal');
hold on;
plot(t, envelope_freq, 'r', 'LineWidth', 1.5, 'DisplayName', 'Envelope (Freq. Domain)');
hold off;
title('Filtered Signal');
xlabel('Time (s)');
ylabel('Amplitude');
legend;
grid on;

analytic_signal_hilbert = hilbert(filtered_signal);
envelope_hilbert = abs(analytic_signal_hilbert);

figure(5);
plot(t, envelope_freq, 'r', 'LineWidth', 4, 'DisplayName', 'Envelope (Freq. Domain)');
hold on;
plot(t, envelope_hilbert, 'k--', 'LineWidth', 2, 'DisplayName', 'Envelope (Hilbert Command)');
hold off;
title('5. Verification of Envelope Extraction Methods');
xlabel('Time (s)');
ylabel('Amplitude');
legend;
grid on;