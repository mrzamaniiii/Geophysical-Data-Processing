Ts = 0.005;          % Sampling time interval
Fs = 1/Ts;           % Sampling frequency
N = 200;             % Number of samples
t = (0:N-1) * Ts;    % Time vector

% 2. Generate Periodic Signal (Sine components in 4-20Hz range) ---

f_a = 5; A_a = 1.0; p_a = 0;
f_b = 10; A_b = 0.6; p_b = pi/3;
f_c = 20; A_c = 0.4; p_c = pi;

signal = A_a * sin(2*pi*f_a*t + p_a) + ...
         A_b * sin(2*pi*f_b*t + p_b) + ...
         A_c * sin(2*pi*f_c*t + p_c);

% Calculate the maximum amplitude
max_signal_amp = max(abs(signal));

% 3. Generate Noise Sequence
noise_percent = 0.30;
max_noise_target = noise_percent * max_signal_amp;

noise_raw = (2 * rand(1, N) - 1); 

current_max_noise = max(abs(noise_raw));
noise = noise_raw * (max_noise_target / current_max_noise);

% 4. Sum Noise and Signal
signal_with_noise = signal + noise;

% 5. Plot Signal and Noise
figure('Name', 'Signal Generation and Noise Addition');

subplot(3, 1, 1);
plot(t, signal, 'b-', 'LineWidth', 1.5);
title('A) Clean Periodic Signal');
ylabel('Amplitude');
grid on;

subplot(3, 1, 2);
plot(t, noise, 'r-', 'LineWidth', 1.5);
title('B) Noise Sequence (Zero Mean, Max Amp ~30% of Signal)');
ylabel('Amplitude');
grid on;

subplot(3, 1, 3);
plot(t, signal_with_noise, 'k-', 'LineWidth', 1.5);
title('C) Result: Signal + Noise');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% 6. Calculate and Plot the Amplitude Spectrum
figure('Name', 'Amplitude Spectrum');

% Calculate FFT
Y_sum = fft(signal_with_noise);

% Calculate One-Sided Amplitude Spectrum
P2 = abs(Y_sum / N);
P1 = P2(1:N/2+1);
P1(2:end-1) = 2 * P1(2:end-1); % Scaling for one-sided

Nyquist = Fs / 2;
f = linspace(0, Nyquist, N/2 + 1);

stem(f, P1, 'm', 'LineWidth', 1.5);
title('Amplitude Spectrum of Signal + Noise');
xlabel('Frequency (Hz)');
ylabel('|P1(f)|');

axis([0 50 0 max(P1)*1.1]);
grid on;