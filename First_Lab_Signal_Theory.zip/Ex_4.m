N = 200;             % Number of samples
Fs = 200;            % Sampling frequency
Nyquist = Fs / 2;    % Nyquist frequency
t = (0:N-1) / Fs;    % Time vector
f = Fs*(0:(N/2))/N;

% Spectrum of a Delta Function
Delta_Spectrum = ones(1, N);

% Inverse Fourier Transform (IFFT)
delta_t = ifft(Delta_Spectrum);

figure('Name', 'Delta Function and White Noise Analysis');

subplot(3, 1, 1);
plot(t, real(delta_t), 'b-', 'LineWidth', 2);
title('Time Domain Result of IFFT(Delta Spectrum)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

max_imag_delta = max(abs(imag(delta_t)));
fprintf('Max absolute imaginary part of delta_t: %e\n', max_imag_delta);


% 1. Amplitude Spectrum
Amplitude_Spectrum_Half = ones(1, N/2 + 1);

Amplitude_Spectrum = [
    Amplitude_Spectrum_Half(1:N/2+1), ... % DC to Nyquist
    fliplr(Amplitude_Spectrum_Half(2:N/2)) % Conjugate mirror from N/2-1 down to 1
];

% 2. Phase Spectrum (Random and Odd)
Random_Phases = 2*pi * rand(1, N/2 - 1);

% Phase vector construction:
Phase_Spectrum = [
    0, ...                             
    Random_Phases, ...                  
    0, ...                              
    -fliplr(Random_Phases)
];

% 3. Complex Spectrum Assembly
WhiteNoise_Spectrum = Amplitude_Spectrum .* exp(1j * Phase_Spectrum);
white_noise_t = ifft(WhiteNoise_Spectrum);

% Plot the result
subplot(3, 1, 2);
plot(t, real(white_noise_t), 'k-', 'LineWidth', 1);
title('Time Domain Result of IFFT(White Noise Spectrum)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Plot the White Noise Amplitude Spectrum
subplot(3, 1, 3);
P1_wn = abs(WhiteNoise_Spectrum(1:N/2+1));
P1_wn(2:end-1) = 2 * P1_wn(2:end-1);
stem(f, P1_wn, 'r', 'LineWidth', 1);
title('White Noise Amplitude Spectrum (Flat)');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
axis([0 Nyquist 0 3]);
grid on;

% Check and display the imaginary part
max_imag_wn = max(abs(imag(white_noise_t)));
fprintf('Max absolute imaginary part of white_noise_t: %e\n', max_imag_wn);