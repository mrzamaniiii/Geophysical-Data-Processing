delta_t = 0.005;
N = 200;
V_sw = 300;
dx = 6;
M = 13;

n_geophones = 0:M-1;
x_geophones = n_geophones * dx;
tau_geophones = x_geophones / V_sw;

f_s = 1 / delta_t;
impulse_response = zeros(1, N);

for i = 1:M
    index = round(tau_geophones(i) / delta_t) + 1;
    if index <= N
        impulse_response(index) = 1;
    end
end

figure;
stem(t, impulse_response, 'filled', 'MarkerSize', 4);
title(sprintf('Impulse Response of Geophone Array', M, dx));
xlabel('Time (s)');
ylabel('Amplitude (Impulse)');
xlim([0 max(t)]);
grid on;
ylim([0 1.1]);

transfer_function_full = fft(impulse_response);
xf_single = f_s * (0:N/2) / N;
amplitude_spectrum = abs(transfer_function_full(1:N/2+1));
amplitude_spectrum_normalized = amplitude_spectrum / max(amplitude_spectrum);

figure;
plot(xf_single, amplitude_spectrum_normalized);
title(sprintf('Transfer Function Amplitude', M, dx));
xlabel('Frequency (Hz)');
ylabel('Amplitude');
xlim([0 f_s/2]);
grid on;