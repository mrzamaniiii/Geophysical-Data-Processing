clear;
clc;
close all;

fs = 1000;              
T = 1;                  
f0 = 180;              
t = 0:1/fs:T-1/fs;      

% sinusoidal signal
x = sin(2*pi*f0*t);

figure(1);
subplot(2,1,1);
plot(t, x);
title('Signal');
xlabel('Time (s)');
ylabel('Amplitude');
%xlim([0 0.05]);

% Amplitude Spectrum
N = length(x);
X_fft = fft(x);
P2 = abs(X_fft/N);
P1 = P2(1:N/2+1);
f = fs*(0:(N/2))/N;

subplot(2,1,2);
plot(f, P1);
title('Amplitude of the Signal');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
grid on;

M = 5;                     
x_down = downsample(x, M);  
fs_down = fs / M;           
t_down = downsample(t, M);

figure(2);
plot(t, x, 'b-');
hold on;
plot(t_down, x_down, 'ro-', 'MarkerFaceColor', 'r'); % Downsampled signal
title('Original - Downsampled Signal');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 0.05]);
legend('Original', 'Downsampled');
grid on;

N_down = length(x_down);
X_fft_down = fft(x_down);
P2_down = abs(X_fft_down/N_down);
P1_down = P2_down(1:N_down/2+1);
P1_down(2:end-1) = 2*P1_down(2:end-1);
f_down = fs_down*(0:(N_down/2))/N_down;

figure(3);
plot(f_down, P2_down);
title('Downsampled Spectrum (0-200Hz)');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
%xlim([0 200]);
grid on;