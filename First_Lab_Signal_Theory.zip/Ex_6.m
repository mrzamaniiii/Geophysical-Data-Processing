
Ts = 0.005;          % Sampling time interval
Fs = 1/Ts;           % Sampling frequency
N = 200;             % Total number of samples
T_pulse = 0.050;     % Pulse duration
N_pulse = T_pulse / Ts;

t = (0:N-1) * Ts;

% Pulse
pulse_shape = hann(N_pulse)'; 
pulse_padded = [pulse_shape, zeros(1, N - N_pulse)]; 

% Reflectivity function
reflectivity = zeros(1, N);
reflectivity(30) = 0.8; 
reflectivity(65) = -0.5;
reflectivity(100) = 1.0;
reflectivity(150) = -0.3;

% 3. Time Domain Convolution
convolution_time_domain_long = conv(pulse_shape, reflectivity);
convolution_time_domain = convolution_time_domain_long(1:N);

% A. Calculate the Spectra
Pulse_Spectrum = fft(pulse_padded);
Reflectivity_Spectrum = fft(reflectivity);

% B. Perform Convolution by Spectra Multiplication
Convolution_Spectrum = Pulse_Spectrum .* Reflectivity_Spectrum;

% C. Apply the Inverse Transform (IFFT)
convolution_freq_domain = ifft(Convolution_Spectrum);

% 5. Comparison Plot
figure('Name', 'Convolution Comparison (Time vs. Frequency Domain)');

subplot(2, 1, 1);
plot(t, convolution_time_domain, 'b-', 'LineWidth', 2);
title('Time Domain Convolution (Baseline)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

subplot(2, 1, 2);
plot(t, real(convolution_freq_domain), 'r--', 'LineWidth', 1.5);
title('Frequency Domain Convolution (IFFT of Spectrum Multiplication)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Check the maximum difference
max_diff = max(abs(real(convolution_freq_domain) - convolution_time_domain));
fprintf('Maximum absolute difference between Time and Frequency domain results: %e\n', max_diff);

% 6. Clear Workspace
clear;
disp('Workspace cleared.');