delta_t = 0.005; 
f_s = 1 / delta_t;
T = 1.0;
f_0 = 10;
f_1 = 60;
N = round(T * f_s);
t = (0:N-1) * delta_t;

signal = chirp(t, f_0, T, f_1, 'linear');

figure;
plot(t, signal);
title(sprintf('Linear Sweep from %.1f Hz to %.1f Hz', f_0, f_1));
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% FFT
fft_signal = fft(signal);
xf_full = f_s * (-N/2 : N/2 - 1) / N;

amp_spectrum = abs(fft_signal / N);
amp_spectrum_single = amp_spectrum(1:N/2+1);
xf_single = f_s * (0:N/2) / N;

figure;
plot(xf_single, amp_spectrum_single);
title('Amplitude Spectrum (FFT)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([0 f_s/2]);
grid on;

N_reflectivity = N;
reflectivity = zeros(1, N_reflectivity);
t_indices = [0.1, 0.2, 0.6, 0.62, 0.85];
amplitudes = [1.0, -0.5, 0.8, -0.7, 0.6];

for i = 1:length(t_indices)
    index = round(t_indices(i) / delta_t) + 1; 
    if index >= 1 && index <= N_reflectivity
        reflectivity(index) = amplitudes(i);
    end
end

figure; 
stem(t, reflectivity, 'filled', 'MarkerSize', 4);
title('Reflectivity Function');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 max(t)]);
ylim([-1.1 1.1]);
grid on;

% Convolution

convolution = conv(signal, reflectivity);
N_conv = length(convolution);
t_conv = (0:N_conv-1) * delta_t;

figure('Name', 'Convolution of Sweep Signal and Reflectivity');
plot(t_conv, convolution);
title('Convolution of Sweep Signal and Reflectivity');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 max(t_conv)]); 
grid on;

% Matched Filter
[compressed_pulse, lags] = xcorr(convolution, signal);
t_matched = lags * delta_t;

figure,
plot(t_matched, compressed_pulse);
title('Apply Matched Filter');
xlabel('Lag Time (s)');
ylabel('Correlation');
xlim([0 max(t_conv)]); 
grid on;


noise = (rand(1, N) * (0.5 - (-0.5))) + (-0.5); 

convolution_noise = conv(noise, reflectivity);
N_conv_noise = length(convolution_noise);
t_conv_noise = (0:N_conv_noise-1) * delta_t;

figure,
plot(t, noise);
title(sprintf('Noise', N));
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 max(t)]);
ylim([-0.55 0.55]);
grid on;

figure,
plot(t_conv_noise, convolution_noise);
title('Convolution noise signal with the reflectivity function');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 max(t_conv_noise)]);
grid on;

% Matched Filter to Result of Convolution noise signal with the reflectivity function

[compressed_noise_pulse, lags_noise] = xcorr(convolution_noise, noise);
t_matched_noise = lags_noise * delta_t;

figure('Name', 'Apply Matched Filter');
plot(t_matched_noise, compressed_noise_pulse);
title('Apply Matched Filter');
xlabel('Lag Time (s)');
ylabel('Correlation');
xlim([0 max(t_conv_noise)]); 
grid on;


