N_rand = 100;
random_vector = rand(1, N_rand); 

figure(1);
plot(random_vector, 'k.', 'MarkerSize', 8);
title('Random Function (Uniform Distribution)');
xlabel('Sample Index');
ylabel('Value (0 to 1)');
grid on;

start_x = 0;
end_x = 4 * pi;      
num_points = 150;    
x = linspace(start_x, end_x, num_points);
y_clean = zeros(1, num_points);

for i = 1:num_points
    y_clean(i) = cos(x(i));
end

noise_amplitude = 0.2;

noise = (2 * noise_amplitude * rand(1, num_points)) - noise_amplitude;

y_noisy = y_clean + noise;

figure(2);

subplot(2, 1, 1);
plot(x, y_clean, 'b-', 'LineWidth', 2);
title('A) Clean Cosine Function');
xlabel('x (radians)');
ylabel('cos(x)');
grid on;

subplot(2, 1, 2);
plot(x, y_clean, 'b--', 'LineWidth', 1, 'DisplayName', 'Clean Signal');
hold on;
plot(x, y_noisy, 'r-', 'LineWidth', 1, 'DisplayName', 'Noisy Signal');
hold off;
title('B) Comparison: Clean vs. Noisy Function');
xlabel('x (radians)');
ylabel('Amplitude');
legend('show');
grid on;