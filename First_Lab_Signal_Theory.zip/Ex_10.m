N = 200;           
Ts = 5e-3;          
T = N * Ts;         
t = 0:Ts:(T-Ts);   

f = 5; 
A_signal = 1;

signal = A_signal * sin(2 * pi * f * t);

A_noise = 2;
noise = rand(1, N) * (2*A_noise) - A_noise;

% Sum the Signal
sum_signal = signal + noise;

figure;
plot(t, signal);
title('Sinusoidal Signal');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

figure;
plot(t, noise);
title('Uniform Noise');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

figure;
plot(t, sum_signal);
title('Sinusoidal Signal with Noise');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;


[autocorolation, lags] = xcorr(sum_signal, 'coeff');

figure;
plot(lags * Ts, autocorolation);
title('Autocorrelation of the Sum');
xlabel('Lag (s)');
ylabel('Autocorrelation Coefficient');
grid on;
