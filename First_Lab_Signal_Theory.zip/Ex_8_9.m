clear all; 
close all;
clc;

N = 200;    
Ts = 0.005;
Fs = 1 / Ts;
t = (0:N-1) * Ts; 

Noise = rand(N, 1) * 1.0 - 0.5;

% Autocorrelation (Time Domain)
R_N_time = xcorr(Noise, 'none');
Lags = -(N-1):(N-1); 

figure(1);
plot(Lags, R_N_time, 'b');
title('Autocorrelation of Noise Signal');
xlabel('Lag (Samples)');
ylabel('R_N(\tau)');
grid on;
saveas(gcf, 'autocorrelation.png');

% FFT
N_fft = fft(Noise);
f = (0:N-1) * Fs / N; % Frequency vector

figure(2);
subplot(2, 1, 1);
plot(f, abs(N_fft));
title('Noise Amplitude Spectrum');
xlabel('Frequency');
ylabel('Amplitude');
grid on;

subplot(2, 1, 2);
plot(f, unwrap(angle(N_fft)));
title('Noise Phase Spectrum');
xlabel('Frequency');
ylabel('Phase (Radians)');
grid on;
saveas(gcf, 'noise_spectra.png');

% Spectrum of the noise autocorrelation
R_N_freq = N_fft .* conj(N_fft);

figure(3);
subplot(2, 1, 1);
plot(f, abs(R_N_freq));
title('Autocorrelation Spectrum Amplitude');
xlabel('Frequency (Hz)');
ylabel('Magnitude (Power)');
grid on;

subplot(2, 1, 2);
plot(f, angle(R_N_freq)); % the un
title('Autocorrelation Spectrum Phase');
xlabel('Frequency (Hz)');
ylabel('Phase (Radians)');
grid on;
saveas(gcf, 'autocorr_spectra_freq.png');




















R_N_ifft = ifft(R_N_freq);
%R_N_ifft_shifted = [R_N_ifft(N/2+1:N); R_N_ifft(1:N/2)];
%R_N_ifft_shifted = real(R_N_ifft_shifted);

figure(4);
plot(Lags, R_N_time, 'b', 'LineWidth', 2, 'DisplayName', 'Autocorrelation');
hold on;

%plot(Lags(N:end), R_N_ifft_shifted, 'r--', 'DisplayName', 'IFFT of Spectrum of the noise autocorrelation', 'LineWidth', 1.5);
plot(Lags(N:end), R_N_ifft, 'r--', 'DisplayName', 'IFFT of Spectrum of the noise autocorrelation', 'LineWidth', 1.5);

title('Comparison');
xlabel('Samples');
ylabel('Magnitude');
legend('show');
grid on;
saveas(gcf, 'comparison_ifft_xcorr.png');
