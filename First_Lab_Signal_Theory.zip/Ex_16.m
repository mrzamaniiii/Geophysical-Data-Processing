clc;
close all;
clear;

N = 32;

impulse = zeros(N, N);
center = N / 2 + 1;
impulse(center, center) = 1;

figure('Name', 'Ideal Pulse and its Spectrum');
subplot(1, 2, 1);
surf(impulse);
title('2D Ideal Pulse');
xlabel('X-axis');
ylabel('Y-axis');
zlabel('Amplitude');
axis tight;



% fft2

F_impulse = fft2(impulse);
F_impulse_shifted = fftshift(F_impulse);
amplitude_spectrum_impulse = abs(F_impulse_shifted);

% Use 'surf' to plot the resulting amplitude spectrum
subplot(1, 2, 2); % Use the second plot in the 1x2 grid
%surf(amplitude_spectrum_impulse);
%title('2. Amplitude Spectrum of Ideal Pulse');
%xlabel('Frequency (u)');
%ylabel('Frequency (v)');
%zlabel('Magnitude');
%axis tight;

%% 3. Generate and Observe Other Simple 2D Functions and Spectra
% =================================================================

% --- Example A: 2D Rectangular Pulse ---
%figure('Name', 'Rectangular Pulse and its Spectrum');
%subplot(1, 2, 1);

% Create a 32x32 matrix of zeros
%rect_pulse = zeros(N, N);

% Create a 9x9 square of ones in the center
%rect_pulse(center-4:center+4, center-4:center+4) = 1;

% Visualize the rectangular pulse
%surf(rect_pulse);
%title('3a. 2D Rectangular Pulse');
%xlabel('X-axis');
%ylabel('Y-axis');
%zlabel('Amplitude');
%zlim([0 1.2]); % Set z-axis limit for better visualization

% Calculate and visualize its amplitude spectrum
%F_rect = fftshift(fft2(rect_pulse));
%amplitude_spectrum_rect = abs(F_rect);
%subplot(1, 2, 2);
%surf(amplitude_spectrum_rect);
%title('3b. Spectrum of Rectangular Pulse (2D Sinc)');
%xlabel('Frequency (u)');
%ylabel('Frequency (v)');
%zlabel('Magnitude');


% --- Example B: 2D Sinusoidal Grating ---
%figure('Name', 'Sinusoidal Grating and its Spectrum');
%subplot(1, 2, 1);

% Create a grid of coordinates for the x and y axes
%[X, Y] = meshgrid(1:N, 1:N);

% Define the frequency of the wave (4 cycles across the grid)
%frequency = 4;

% Generate a 2D cosine wave that varies along the X-axis
%sinusoid = cos(2 * pi * frequency * X / N);

% Visualize the sinusoidal grating
%surf(X, Y, sinusoid);
%title('4a. 2D Sinusoidal Grating');
%xlabel('X-axis');
%ylabel('Y-axis');
%zlabel('Amplitude');

% Calculate and visualize its amplitude spectrum
%F_sinusoid = fftshift(fft2(sinusoid));
%amplitude_spectrum_sinusoid = abs(F_sinusoid);
%subplot(1, 2, 2);
%surf(amplitude_spectrum_sinusoid);
%title('4b. Spectrum of Sinusoid');
%xlabel('Frequency (u)');
%ylabel('Frequency (v)');
%zlabel('Magnitude');